봇_토큰 = "MTIxMzMzMzk0NjgzODgxNDczMA.G8Hdz-." #봇의 토큰
관리자아이디 = [772310119999733772] #라이센스 뽑을 수 있는 사람의 아이디
API_엔드포인트 = "https://discord.com/api/v9"  #웬만해선 안건드려도됨
클라이언트_아이디 = "1213333946838814730" #디스코드 개발자 센터 Oauth2 탭에 들어가면 있는 Client ID
클라이언트_시크릿 = "" #디스코드 개발자 센터 Oauth2 탭에 들어가면 있는 Client Secret
도메인 = "https://ghost123.restorebank.xyz" #복구봇을 이용할 도메인
복구키사용웹훅 = "https://discord.com/api/webhooks/1232314961338826834/Sqo-gnNgSF1oE6Fi_m5CJ4lJhJLF_gUD9yobZrn-1b5wRIkQuIcdnT8yJ5okzhfg9DsX"
########### 건드리지 마세요 ###########
token = 봇_토큰
admin_id = 관리자아이디
api_endpoint = API_엔드포인트
client_id = 클라이언트_아이디
client_secret = 클라이언트_시크릿
base_url = 도메인
bokweb=복구키사용웹훅
########### 건드리지 마세요 ###########
